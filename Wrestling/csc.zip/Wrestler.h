#include <iostream>
#include <iomanip>
class Wrestler{
public:
	Wrestler(int i, int w, int ab){
		id = i;
		weight = w;
		abilityScore = ab;
		
	}
	int getID(){return id;}
	int getWeight(){return weight;}
	//~Wrestler();
	void print(){//For testing.
		std::cout << "ID: " << id << " | Weight: "<< std::setw(3) << weight << " | Ability Score: " << abilityScore << std::endl;
	}
private:
	int weight;
	int id;
	int abilityScore;
};