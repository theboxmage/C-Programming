#include <iostream>
#include <list>
#include <random>
#include <ctime>
#include "Team.h"

std::list<Team> list;
std::list<Team>::iterator litr;
int main()
{
	std::default_random_engine gen(time(NULL));
	for(int i = 1; i < 9; i++)
	{
		Team * teamptr = new Team(i, gen);
		list.push_back(*teamptr);
	}
	litr = list.begin();
	while(litr!=list.end())
	{
		//litr->display();
		litr++;
	}
}

