#include "Wrestler.h"
#include <vector>

class Team{
public:
	///ID is an x*100 value, so the 1-99 values will be empty for unique member ID.

	
	Team(int id, std::default_random_engine &gen)
	{
		std::uniform_int_distribution <int> Idist(10, 18);
		std::normal_distribution <double> ndist(100,15);
		std::uniform_int_distribution <int> WeiDist(93, 285);
		int r = Idist(gen);
		ide =id;
		for(int i = 0; i < r; i++)
		{
			members.push_back(Wrestler(id*100+i+1, WeiDist(gen), ndist(gen)));
		}
		
		for(int i=0; i<12; i++)
		{
			
		}
		
		fillWeightClass();
	}
	
	void fillWeightClass()
	{
		titr = members.begin();
		std::vector<Wrestler> hold;
		std::cout << "Team ID:" << ide << std::endl; 
		while(titr!=members.end())
		{
			hold.push_back(*titr);
			titr++;
		}
		
		while(titr!=members.end())
		{
			hold.push_back(*titr);
			titr++;
		}
	}
	
	void display()
	{
		titr = members.begin();
		std::cout << "Team ID: " << titr->getID()/100 << std::endl;
		std::cout << "----------------------------------------" << std::endl;
		while(titr!=members.end())
		{
			titr->print();
			titr++;
		}
		std::cout << std::endl;
	}
	
	void displayByWeightClass()
	{
		
	}
private:
	int count;
	int ide;
	std::vector<Wrestler> weightClass;
	std::list<Wrestler> members;
	std::list<Wrestler>::iterator titr;
	void weightClasses();
};